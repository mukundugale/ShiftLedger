# ShiftLedger

Candidate: Mukund Ugale
Machine Name :  ShiftLedger
Domain:  Web Exploitation
Operating System:  Ubuntu 24.04 LTS
Difficulty:  Medium–Hard

## Scenario

Internal payroll portal for a logistics company — escalate from a single
low-privilege employee account to full root compromise of the target machine.

Meridian Logistics runs an internal web portal, ShiftLedger, used by warehouse
staff to view shifts, clock in and out, and submit payroll adjustment requests; the Finance team exports
approved adjustments as payslip batches each pay period.

You have been engaged as an external penetration tester and provided with a
single low-privilege employee account on the ShiftLedger portal. Your
objective is to determine how far that access can be escalated on the single
target machine.

## Starting access

```
URL:      http://<target-ip>/
Username: alice
Password: Welcome123!
Role:     employee
```

No further credentials are provided or required. Brute-forcing or guessing
additional credentials is not part of the intended solve path.

## Deployment

On a clean Ubuntu 24.04 LTS install (8 vCPU / 16 GB RAM / 100 GB storage is
more than sufficient):

```bash
sudo bash build/setup.sh
```

This installs all dependencies, configures the web application, the backup
service, and nginx, seeds the database, and starts everything automatically.
No manual steps are required.

## Health check

```bash
sudo bash build/health_check.sh
```

Confirms the web application, backup service, and nginx are all active and
that the application is responding on port 80.

## Reset

```bash
sudo bash build/reset.sh
```

Restores the database to its seeded state and clears any files left behind
by a previous solve attempt, without requiring a full re-install.

## Objective

Full compromise of the target machine (root access).
