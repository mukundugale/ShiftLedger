from app import app
from models import db, User, Shift, AdjustmentRequest

with app.app_context():
    db.drop_all()
    db.create_all()

    people = [
        ("alice", "Alice Nguyen", "Warehouse Ops", "employee", "Welcome123!"),
        ("dave", "Dave Thompson", "Warehouse Ops", "employee", "Warehouse2026!"),
        ("priya", "Priya Raman", "Inbound Logistics", "employee", "Inbound2026!"),
        ("marcus", "Marcus Webb", "Fleet Dispatch", "employee", "Dispatch2026!"),
        ("bob.supervisor", "Bob Martinez", "Warehouse Ops", "supervisor", "SupervisorPass1!"),
        ("rita.supervisor", "Rita Alvarez", "Inbound Logistics", "supervisor", "SupervisorPass2!"),
        ("carol.finance", "Carol Jensen", "Finance & Payroll", "finance_admin", "FinanceSecure1!"),
    ]

    users = {}
    for username, full_name, dept, role, pw in people:
        u = User(username=username, full_name=full_name, department=dept, role=role)
        u.set_password(pw)
        db.session.add(u)
        users[username] = u

    db.session.commit()

    shifts = [
        Shift(user_id=users["alice"].id, date="2026-10-13", start_time="08:00", end_time="16:00"),
        Shift(user_id=users["alice"].id, date="2026-10-14", start_time="08:00", end_time="16:00"),
        Shift(user_id=users["alice"].id, date="2026-10-15", start_time="08:00", end_time="16:00"),
        Shift(user_id=users["dave"].id, date="2026-10-13", start_time="16:00", end_time="00:00"),
        Shift(user_id=users["dave"].id, date="2026-10-14", start_time="16:00", end_time="00:00"),
        Shift(user_id=users["priya"].id, date="2026-10-13", start_time="06:00", end_time="14:00"),
        Shift(user_id=users["marcus"].id, date="2026-10-13", start_time="09:00", end_time="17:00"),
    ]
    db.session.add_all(shifts)

    requests = [
        AdjustmentRequest(user_id=users["alice"].id, reason="Covered extra pallet-count shift",
                           hours_claimed=2.5, status="pending"),
        AdjustmentRequest(user_id=users["dave"].id, reason="Late truck arrival, stayed past clock-out",
                           hours_claimed=1.0, status="pending"),
        AdjustmentRequest(user_id=users["priya"].id, reason="System downtime during receiving, manual count",
                           hours_claimed=3.0, status="approved", approver_role="supervisor"),
        AdjustmentRequest(user_id=users["marcus"].id, reason="Weekend emergency dispatch call-in",
                           hours_claimed=4.0, status="pending"),
    ]
    db.session.add_all(requests)
    db.session.commit()

    print("Seed data created for Meridian Logistics - ShiftLedger")
    print("Accounts:")
    for username, full_name, dept, role, pw in people:
        print(f"  {username:16s} ({role:13s}) / {pw}")
