from flask import Flask, render_template, request, redirect, session, url_for
from jinja2 import Template
from models import db, User, Shift, AdjustmentRequest
import os

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev-placeholder-change-me")
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///" + os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "shiftledger.db"
)
db.init_app(app)


def current_user():
    if "user_id" not in session:
        return None
    return User.query.get(session["user_id"])


# ---------- Auth ----------

@app.route("/")
def index():
    return redirect(url_for("dashboard") if current_user() else url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            session["user_id"] = user.id
            session["role"] = user.role
            return redirect(url_for("dashboard"))
        return render_template("login.html", error="Invalid username or password")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ---------- Dashboard ----------

@app.route("/dashboard")
def dashboard():
    user = current_user()
    if not user:
        return redirect(url_for("login"))
    shifts = Shift.query.filter_by(user_id=user.id).all()
    return render_template("dashboard.html", user=user, shifts=shifts)


# ---------- Adjustment requests (Stage 1 lives here) ----------

@app.route("/adjustments", methods=["GET", "POST"])
def adjustments():
    user = current_user()
    if not user:
        return redirect(url_for("login"))

    if request.method == "POST":
        reason = request.form.get("reason", "").strip()
        hours = request.form.get("hours_claimed", "0")
        try:
            hours = float(hours)
        except ValueError:
            hours = 0.0
        if reason:
            req = AdjustmentRequest(
                user_id=user.id, reason=reason, hours_claimed=hours, status="pending"
            )
            db.session.add(req)
            db.session.commit()
        return redirect(url_for("adjustments"))

    my_requests = AdjustmentRequest.query.filter_by(user_id=user.id).all()
    return render_template("adjustments.html", user=user, requests=my_requests)


@app.route("/adjustments/<int:req_id>/amend", methods=["POST"])
def amend_adjustment(req_id):
    user = current_user()
    if not user:
        return redirect(url_for("login"))

    req = AdjustmentRequest.query.get_or_404(req_id)
    if req.user_id != user.id:
        return "Forbidden", 403

    # Intended: only let an employee tweak the reason/note on their own
    # still-pending request. Unintended: the handler blindly accepts
    # whatever fields are present in the submitted form.
    allowed_in_ui = {"reason", "note"}
    for field in ["reason", "note", "hours_claimed", "status", "approver_role"]:
        if field in request.form:
            value = request.form.get(field)
            if field == "hours_claimed":
                try:
                    value = float(value)
                except ValueError:
                    continue
            setattr(req, field, value)

    # Downstream of approval: when a request is marked "approved" with an
    # approver_role set, the payroll sync treats that as proof the
    # requester was acting with that role's delegated authority, and
    # mirrors the role onto the requester's own account. Intended for a
    # supervisor's assistant workflow; it never re-checks who actually
    # set these fields, so the mass-assignment above flows straight
    # into a real privilege change.
    if req.status == "approved" and req.approver_role in ("supervisor", "finance_admin"):
        user.role = req.approver_role
        session["role"] = req.approver_role

    db.session.commit()
    return redirect(url_for("adjustments"))


# ---------- Supervisor approval queue (legitimate workflow) ----------

@app.route("/supervisor/queue")
def supervisor_queue():
    user = current_user()
    if not user:
        return redirect(url_for("login"))
    if user.role not in ("supervisor", "finance_admin"):
        return "Forbidden - supervisor only", 403

    pending = (
        AdjustmentRequest.query.filter_by(status="pending")
        .join(User, AdjustmentRequest.user_id == User.id)
        .filter(User.department == user.department)
        .all()
    ) if user.role == "supervisor" else AdjustmentRequest.query.filter_by(status="pending").all()

    return render_template("supervisor_queue.html", user=user, pending=pending)


@app.route("/supervisor/queue/<int:req_id>/decide", methods=["POST"])
def supervisor_decide(req_id):
    user = current_user()
    if not user:
        return redirect(url_for("login"))
    if user.role not in ("supervisor", "finance_admin"):
        return "Forbidden - supervisor only", 403

    req = AdjustmentRequest.query.get_or_404(req_id)
    decision = request.form.get("decision")
    if decision in ("approved", "rejected"):
        req.status = decision
        req.approver_role = user.role if decision == "approved" else None
        db.session.commit()
    return redirect(url_for("supervisor_queue"))


# ---------- Supervisor promotion (Stage 2) ----------

@app.route("/supervisor/grant", methods=["POST"])
def supervisor_grant():
    user = current_user()
    if not user:
        return redirect(url_for("login"))

    # Intended: only a supervisor approving a *specific* finance-export
    # delegation for a specific task should be able to call this.
    # Unintended: it trusts the target role from the request body and
    # only checks that the caller isn't a plain employee - it doesn't
    # verify they hold a specific finance-delegation permission.
    target_role = request.form.get("target_role", "")
    if user.role in ("supervisor", "finance_admin") and target_role in (
        "supervisor",
        "finance_admin",
    ):
        user.role = target_role
        session["role"] = target_role
        db.session.commit()
        return redirect(url_for("export_payslips"))
    return "Forbidden", 403


# ---------- Payslip export / SSTI (Stage 3) ----------

BLOCKED_SUBSTRINGS = ["__", "import", "popen", "system", "exec(", "eval("]


@app.route("/export", methods=["GET", "POST"])
def export_payslips():
    user = current_user()
    if not user:
        return redirect(url_for("login"))
    if user.role != "finance_admin":
        return "Forbidden - finance_admin only", 403

    output = None
    blocked = False

    if request.method == "POST":
        memo = request.form.get("memo", "")
        if any(b in memo for b in BLOCKED_SUBSTRINGS):
            blocked = True
        else:
            # Memo is rendered as part of the TEMPLATE itself, not
            # passed in as template *data* - this is the SSTI.
            tmpl = Template("Payslip batch memo: " + memo)
            output = tmpl.render()

    approved_requests = AdjustmentRequest.query.filter_by(status="approved").all()
    return render_template(
        "export.html", output=output, blocked=blocked, approved_requests=approved_requests
    )


@app.route("/profile")
def profile():
    user = current_user()
    if not user:
        return redirect(url_for("login"))
    return render_template("profile.html", user=user)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
