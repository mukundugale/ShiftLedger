# Attribution & Originality Declaration

## Originality declaration

ShiftLedger — the application, scenario, data model, and all four
vulnerabilities (mass-assignment self-approval, trusted-field role
escalation, constrained server-side template injection, and insecure
deserialization in a privileged background service) — was designed and
implemented by the candidate specifically for this assessment. No code,
configuration, scenario, or solve path was copied from Hack The Box,
TryHackMe, VulnHub, PortSwigger Web Security Academy, or any other
third-party platform.

## References consulted (concepts only, not copied material)

- PortSwigger Web Security Academy — general background reading on
  server-side template injection concepts (no labs, scenarios, or specific
  payloads from the Academy were copied; the filter-bypass technique and
  exact chain used here were independently constructed and tested for this
  application).
- Public documentation for Flask, Jinja2, and Python's `pickle` module —
  used to understand intended behavior, not as a source of exploit code.
- General, widely-known public knowledge of insecure deserialization as a
  vulnerability class (e.g. publicly documented CVEs involving Python
  `pickle` in internal job-processing services) informed the design of
  Stage 4, adapted into an original daemon implementation written for this
  submission.

## Third-party software (not authored by the candidate)

- Flask, Flask-SQLAlchemy, Werkzeug, Jinja2 (BSD-licensed) — used as the
  web framework; configuration, routes, templates, and business logic
  (including the intentional vulnerabilities) are original.
- nginx (BSD-licensed) — used unmodified as a reverse proxy.
- Ubuntu 24.04 LTS — base operating system, unmodified aside from the
  setup script's configuration.

No proprietary or restrictively-licensed third-party code is included.
